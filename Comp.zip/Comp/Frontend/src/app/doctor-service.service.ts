import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DoctorClass } from './doctor-class';
import { catchError, Observable, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class DoctorServiceService {
  private serverUrl:string = `http://localhost:8081`;
  constructor(private httpClient:HttpClient) { }

  //error handling
  public handleError(error: HttpErrorResponse) {
    let errorMessage: string = ``;
    if (error.error instanceof ErrorEvent) {
      //client error
      errorMessage = `Error : ${error.error.message}`;
    }
    else {
      //server error
      errorMessage = `status : ${error.status}`;
    }
    return throwError(() => errorMessage);
  }

  //get all Doctor
  public getAllDoctors():Observable<DoctorClass[]>{
    let dataUrl:string = `http://localhost:8081/doctor/getAllDoc`;
    return this.httpClient.get<DoctorClass[]>(dataUrl).pipe(catchError(this.handleError));
  }
   //get Doctor by name
   public getDoctor(name:string):Observable<DoctorClass>{
     
    let dataUrl:string = `${this.serverUrl}/doctor/getDocByName/${name}`;
    return this.httpClient.get<DoctorClass>(dataUrl).pipe(catchError(this.handleError));
  }
  //create doctor
  public createDoctor(Dgroup: DoctorClass): Observable<DoctorClass> {
    let dataUrl: string = `${this.serverUrl}/doctor/createDoctor`;
    return this.httpClient.post<DoctorClass>(dataUrl, Dgroup).pipe(catchError(this.handleError));
  }

}
