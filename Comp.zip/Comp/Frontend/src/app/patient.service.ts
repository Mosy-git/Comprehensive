import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DoctorClass } from './doctor-class';
import { PatientClass } from './patient-class';
import { catchError, Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})


export class PatientService {

  private serverUrl:string = `http://localhost:8082`;
  constructor(private httpClient:HttpClient) { }

  //error handling
  public handleError(error: HttpErrorResponse) {
    let Message: string = ``;
    if (error.error instanceof ErrorEvent) {
      //client error
      Message = `Error : ${error.error.message}`;
    }
    else {
      //server error
      Message = `status : ${error.status}`;
    }
    return throwError(() => Message);
  }

  //get all Doctor
  public getAllDoctors():Observable<DoctorClass[]>{
    let dataUrl:string = `http://localhost:8081/doctor/getAllDoc`;
    return this.httpClient.get<DoctorClass[]>(dataUrl).pipe(catchError(this.handleError));
  }


  //get Patient by id
  public getPatient(patient_id:number):Observable<PatientClass>{
    let dataUrl:string = `${this.serverUrl}/patient/getPatientById/${patient_id}`;
    return this.httpClient.get<PatientClass>(dataUrl).pipe(catchError(this.handleError));
  }
  //create patient
  public CreatePatient(Pgroup:PatientClass): Observable<PatientClass> {
    let dataUrl: string = `${this.serverUrl}/patient/createPatient`;
    return this.httpClient.post<PatientClass>(dataUrl, Pgroup).pipe(catchError(this.handleError));
  }



}
