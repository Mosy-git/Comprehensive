export class PatientClass {
    id?: number;
    name?: string;
    visitedDoctor?: string;
    dateOfVisit?: Date;
    doctorprescription?: string;
}
