import { PatientClass } from './patient-class';

describe('PatientClass', () => {
  it('should create an instance', () => {
    expect(new PatientClass()).toBeTruthy();
  });
});
