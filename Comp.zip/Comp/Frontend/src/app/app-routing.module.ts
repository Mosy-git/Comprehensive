import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DoctorComponent } from './doctor/doctor.component';
import { HomeComponent } from './home/home.component';
import { PatientComponent } from './patient/patient.component';
import { ViewDoctorComponent } from './view-doctor/view-doctor.component';
import { ViewPatientComponent } from './view-patient/view-patient.component';

const routes: Routes = [
  {path : 'doctors', component: DoctorComponent},
  {path: 'doctor', redirectTo: 'doctors', pathMatch: 'full'},

  {path:'', redirectTo:'/home' , pathMatch : 'full'},
  {path:'doctors/doctor/add' , component: DoctorComponent},
  {path:'doctor/view' , component: ViewDoctorComponent},
  {path:'patients/patient/add' , component: PatientComponent},
  {path:'patient/view' , component: ViewPatientComponent},
{path:'**',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
