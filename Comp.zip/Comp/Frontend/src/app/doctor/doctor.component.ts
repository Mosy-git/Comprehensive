import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DoctorClass } from '../doctor-class';
import { DoctorServiceService } from '../doctor-service.service';

@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']
})
export class DoctorComponent implements OnInit {
  
  public doctor:DoctorClass = {} as DoctorClass;
  
  constructor(private service:DoctorServiceService,private router:Router) { }

  ngOnInit(): void {
  }
  saveDoctor(){
    this.service.createDoctor(this.doctor).subscribe({
      next: (data)=>{
        alert("DOCTOR ADDED TO THE HOSPITAL DATABASE");
        this.router.navigate(['/']).then();
        
      },
      error: (e)=>{
        this.router.navigate(['/doctors/doctor/add']).then();
        alert("Error occured ! Try again..");

      }
    })
  }

}
