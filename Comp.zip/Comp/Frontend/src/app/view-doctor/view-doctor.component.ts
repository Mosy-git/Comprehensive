import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DoctorClass } from '../doctor-class';
import { DoctorServiceService } from '../doctor-service.service';

@Component({
  selector: 'app-view-doctor',
  templateUrl: './view-doctor.component.html',
  styleUrls: ['./view-doctor.component.css']
})
export class ViewDoctorComponent implements OnInit {


  public doctor:DoctorClass[] = [] ;
  public errorMessage:string | null = null;
  public name:string|null = null;
  public doc:DoctorClass = {} as DoctorClass; 

  constructor(private activatedRoute:ActivatedRoute, private service:DoctorServiceService) { }

  ngOnInit(): void {

    this.service.getAllDoctors().subscribe({
      next :(data)=>{
        this.doctor = data;
      }
    });
  }

  viewDoctor(){
    if(this.doc.name){
      console.warn(this.doc.name);
      this.service.getDoctor(this.doc.name).subscribe({
        next: (data)=>{
          console.warn(data);
          this.doc = data;
        },
        error: (e)=>{
          this.errorMessage = e;
        }
      })
    }
  }

}
