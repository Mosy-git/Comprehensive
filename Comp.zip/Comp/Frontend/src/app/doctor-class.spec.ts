import { DoctorClass } from './doctor-class';

describe('DoctorClass', () => {
  it('should create an instance', () => {
    expect(new DoctorClass()).toBeTruthy();
  });
});
