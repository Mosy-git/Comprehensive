import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PatientClass } from '../patient-class';
import { PatientService } from '../patient.service';

@Component({
  selector: 'app-view-patient',
  templateUrl: './view-patient.component.html',
  styleUrls: ['./view-patient.component.css']
})
export class ViewPatientComponent implements OnInit {

  public id:number | null= null ;
  public patient:PatientClass = {} as PatientClass;
  public errorMessage:string|null = null;

  constructor(private service:PatientService , private router :Router) { }

  ngOnInit(): void {
  }


  viewPatient(){
    if(this.id == null){
    
    }
    else if(this.id){
      this.service.getPatient(this.id).subscribe({
        next : (data)=>{
          this.patient = data;
        },
        error : (e)=>{
          
          this.errorMessage = "No such patient there in the database";
          alert(this.errorMessage);
        }

      });
    }
    }
  
}
