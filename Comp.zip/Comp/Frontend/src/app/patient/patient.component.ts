import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DoctorClass } from '../doctor-class';
import { PatientClass } from '../patient-class';
import { PatientService } from '../patient.service';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit {

   public patient: PatientClass = {} as PatientClass;
   public doctors: DoctorClass[] = {} as DoctorClass[];
   public errorMessage: string | null = null;

  constructor(private service:PatientService , private router:Router) { }

  ngOnInit(): void {
    this.service.getAllDoctors().subscribe({
      next:(data) =>{
        this.doctors = data;
      }
    })
  }
  savePatient(){
    this.service.CreatePatient(this.patient).subscribe({
      next:(data)=>{
        alert("Patient Added to the database")
        this.router.navigate(['/']).then();
      },
      error:(e)=>{
        this.errorMessage = e;
        console.warn(e);
        alert("Invalid Information")
        this.router.navigate(['/patients/patient/add']).then();
      }
    });
  }

}
