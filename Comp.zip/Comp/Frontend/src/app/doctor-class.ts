export class DoctorClass {
    id?: number;
    name?: string;
    age?: number;
    gender?: String;

    specialist?: String;
    NoOfPatientsAttended?: number;
}
