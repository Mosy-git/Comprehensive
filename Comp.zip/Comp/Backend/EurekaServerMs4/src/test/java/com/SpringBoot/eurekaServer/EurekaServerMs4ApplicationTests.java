package com.SpringBoot.eurekaServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerMs4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
