package com.mindtree.restController;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.Exceptions.NoDoctorFound;
import com.mindtree.dao.Doctor;
import com.mindtree.service.DoctorService;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/doctor")
public class DoctorController {
	@Autowired
	DoctorService ser;
	
	@PostMapping("/createDoctor")
	public String createDoctor(@RequestBody Doctor doc) {
		return ser.createNewDoctor(doc);
	}
	
	@GetMapping("/getAllDoc")
	public List<Doctor> getAllDoc(){
		return ser.getAllDoctors();
	}
	
	@GetMapping("/getDocById/{id}")
	public Doctor getById(@PathVariable("id") int id ) throws NoDoctorFound{
		Doctor doc= ser.getDoctorById(id);
		if(doc==null) throw new NoDoctorFound("no doctor with id"+id+"is available");
		else return doc;
	}
	@GetMapping("/getDocByName/{id}")
	public Doctor getByName(@PathVariable("id") String name ) throws NoDoctorFound{
		Doctor doc= ser.getDoctorByName(name);
		if(doc==null) throw new NoDoctorFound("no doctor with name"+name+"is available");
		else return doc;
	}
}
