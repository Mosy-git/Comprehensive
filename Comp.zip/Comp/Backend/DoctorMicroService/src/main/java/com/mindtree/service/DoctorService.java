package com.mindtree.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.Doctor;
import com.mindtree.repo.DoctorRepo;

@Service
public class DoctorService {
	@Autowired
	DoctorRepo repo;

	public String createNewDoctor(Doctor doc) {
		repo.save(doc);
		return "doc with name "+doc.getName()+" with id "+doc.getId();
	}

	public List<Doctor> getAllDoctors() {
		return repo.findAll();
	}
	public Doctor getDoctorById(int id) {
		Doctor doc=repo.findById(id).get();
		return doc;
	}

	public Doctor getDoctorByName(String name) {
		Doctor doc = repo.findByName(name).get();
		return doc;
	}
}
