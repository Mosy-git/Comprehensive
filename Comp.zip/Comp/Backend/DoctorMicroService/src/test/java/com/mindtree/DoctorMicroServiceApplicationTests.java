package com.mindtree;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mindtree.dao.Doctor;
import com.mindtree.repo.DoctorRepo;

@SpringBootTest
class DoctorMicroServiceApplicationTests {

	@Autowired
	DoctorRepo dRepo;
	
	//test to store and get data from database both post and get
	@Test
	public void test() {
		Doctor doc = new Doctor();
		doc.setId(5);
		doc.setName("DoctorTest");
		doc.setAge(45);
		doc.setGender("Male");
		doc.setSpecialist("Special5");
		doc.setNoOfPatientsAttended(333);
		
		dRepo.save(doc);
		assertNotNull(dRepo.findById(5).get());
	}
	
	//test to read all the records from database
	@Test
	public void testReadAll() {
		
		List<Doctor> list = dRepo.findAll();
		assertThat(list).size().isGreaterThan(0);
		
	}
	
	
}
