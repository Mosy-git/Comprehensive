package com.mindtree.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.entity.Patient;
import com.mindtree.repo.PatientRepo;

@Service
public class PatientService {
	@Autowired
	PatientRepo repo;

	public String createNewPatient(Patient doc) {
		repo.saveAndFlush(doc);
		return "patient with name "+doc.getName()+" with id "+doc.getId();
	}

	public Patient getPatientById(int id) {
		Patient patient = repo.findById(id).get();
		return patient;
	}

}
