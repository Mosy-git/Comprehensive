package com.mindtree;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mindtree.entity.Patient;
import com.mindtree.repo.PatientRepo;

@SpringBootTest
class PatientMicroServiceApplicationTests {

	@Autowired
	PatientRepo dRepo;
	
	//test to store and get data from database both post and get
	@Test
	public void test() {
		Patient pat = new Patient();
		pat.setId(5);
		pat.setName("PatientTest");
		pat.setVisitedDoctor("DoctorTest");
		pat.setDateOfVisit("12122021");
		pat.setDoctorprescription("Test Prescription");
		
		dRepo.save(pat);
		assertNotNull(dRepo.findById(5).get());
	}
	
	//test to read all the records from database
	@Test
	public void testReadAll() {
		
		List<Patient> list = dRepo.findAll();
		assertThat(list).size().isGreaterThan(0);
		
	}

}
